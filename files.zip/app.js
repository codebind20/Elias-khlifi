(()=>{
document.documentElement.classList.add('js');
const D={
AI:'Claude AI Chat|AI Summarizer|AI Rewriter|AI Translator|AI Proofreader|AI Explainer|AI Email Writer|AI Cover Letter|AI CV Assistant|AI German Practice|AI French Practice|AI Arabic Assistant|AI Content Writer|AI Social Captions|AI Idea Generator|AI Outline Maker|AI Meeting Notes|AI Task Planner|AI Compare|AI Quiz Maker|AI Flashcards|AI SQL Helper|AI Code Helper|AI Regex Helper|AI JSON Helper|AI Prompt Builder',
PDF:'Merge PDF*|Compress PDF*|JPG to PDF*|PDF to JPG*|Split PDF*|Protect PDF*|PDF Watermark*|Sign PDF*|PDF to Text*|PDF Page Counter*',
Images:'Image Compressor|Image Resizer|JPG to PNG|Image Cropper|Image Rotator|Image Flipper|Grayscale Image|Image Info',
Calculators:'Age Calculator|BMI Calculator|Percentage Calculator|Discount Calculator|Loan Calculator|Compound Interest|Simple Interest|Tip Calculator|Sales Tax Calculator|Profit Margin|Break-even Calculator|Salary Converter|Date Difference|Unit Price Calculator',
Text:'Word Counter|Case Converter|Character Counter|Remove Extra Spaces|Sort Lines|Remove Duplicate Lines|Reverse Text|Slug Generator|Extract Emails|Extract URLs|Extract Numbers|Text Statistics',
Developer:'JSON Formatter|JSON Minifier|Base64 Encoder|Base64 Decoder|URL Encoder|URL Decoder|HTML Escape|HTML Unescape|Unix Timestamp|Color Converter|SQL Formatter|JWT Decoder|UUID Generator',
Security:'Password Generator|Passphrase Generator|Password Strength|SHA-256 Hash|SHA-512 Hash|Secret Token Generator|PIN Generator',
Converters:'QR Code Generator|Random Number|Temperature Converter|Unit Converter|Length Converter|Weight Converter|Area Converter|Volume Converter|Speed Converter|Data Size Converter|Number Base Converter|Time Zone Converter|Currency Converter*'};
const all=[];
Object.keys(D).forEach(c=>D[c].split('|').forEach(n=>{const soon=n.endsWith('*');n=n.replace('*','');all.push({c,n,soon,s:n.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')})}));
const $=s=>document.querySelector(s),grid=$('#grid'),q=$('#q'),tabs=$('#tabs'),cnt=$('#count'),none=$('#none');
const mk=(t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x)e.textContent=x;return e};
let cat='All';
function draw(){
 const v=q.value.trim().toLowerCase();let n=0;grid.textContent='';
 all.forEach(t=>{
  if((cat==='All'||t.c===cat)&&(!v||t.n.toLowerCase().includes(v)||t.c.toLowerCase().includes(v))){
   n++;const el=t.soon?mk('div','card soon'):mk('a','card');
   if(!t.soon)el.href='/tools/'+t.s+'/';
   el.append(mk('span','tag',t.c),mk('strong','',t.n));
   if(t.soon)el.append(mk('em','badge','Soon'));
   grid.append(el)}});
 cnt.textContent=n+(n===1?' tool':' tools');none.hidden=n>0}
['All',...Object.keys(D)].forEach(c=>{
 const b=mk('button','',c);b.type='button';b.setAttribute('aria-pressed',c==='All');
 b.onclick=()=>{cat=c;tabs.querySelectorAll('button').forEach(x=>x.setAttribute('aria-pressed',x===b));draw()};
 tabs.append(b)});
q.addEventListener('input',draw);
const p=new URLSearchParams(location.search).get('q');if(p)q.value=p;
document.addEventListener('keydown',e=>{if(e.key==='/'&&!/INPUT|TEXTAREA/.test(document.activeElement.tagName)){e.preventDefault();q.focus()}});
$('#yr').textContent=new Date().getFullYear();
draw();
const io='IntersectionObserver'in window?new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.15}):null;
document.querySelectorAll('.rv').forEach(el=>io?io.observe(el):el.classList.add('in'));
})();
